"""In-memory conversation history model."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Message:
    """A single message in a conversation.

    Attributes:
        role: Either ``"user"`` or ``"assistant"``.
        content: The text of the message.
    """

    role: str
    content: str


class Conversation:
    """Manages an ordered list of Messages for a single chat session.

    The conversation lives entirely in memory and is never written to disk
    by this class.  It is the caller's responsibility to persist it if needed.
    """

    def __init__(self) -> None:
        self._messages: list[Message] = []

    # ------------------------------------------------------------------
    # Mutations
    # ------------------------------------------------------------------

    def add_message(self, role: str, content: str) -> None:
        """Append a new message to the conversation.

        Args:
            role: ``"user"`` or ``"assistant"``.
            content: The message text.
        """
        self._messages.append(Message(role=role, content=content))

    def clear(self) -> None:
        """Remove all messages from the conversation."""
        self._messages = []

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_history(self) -> list[Message]:
        """Return a shallow copy of the message list."""
        return list(self._messages)

    def is_empty(self) -> bool:
        """Return True when there are no messages."""
        return len(self._messages) == 0

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_list(self) -> list[dict]:
        """Serialise the conversation to a list of plain dicts."""
        return [{"role": m.role, "content": m.content} for m in self._messages]

    @classmethod
    def from_list(cls, data: list[dict]) -> "Conversation":
        """Reconstruct a Conversation from a list of plain dicts.

        Args:
            data: A list as produced by ``to_list()``.

        Returns:
            A new Conversation instance populated with the given messages.
        """
        conv = cls()
        for item in data:
            conv.add_message(role=item["role"], content=item["content"])
        return conv
