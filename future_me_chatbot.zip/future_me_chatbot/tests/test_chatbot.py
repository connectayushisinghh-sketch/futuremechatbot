"""Unit tests for chatbot.py — RuleBasedChatbot response engine."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

from chatbot import RuleBasedChatbot, TOPIC_KEYWORDS
from profile import FutureMeProfile


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def bot() -> RuleBasedChatbot:
    return RuleBasedChatbot()


@pytest.fixture()
def full_profile() -> FutureMeProfile:
    return FutureMeProfile(
        name="Alex",
        time_horizon=5,
        career_aspirations="Become a senior software engineer",
        personal_goals="Run a marathon and write a novel",
        habits="Daily exercise and morning journaling",
        achievements="Launch an open-source project",
        lifestyle="Remote work near the ocean",
        values="Integrity, curiosity, and kindness",
        future_notes="Stay focused on growth.",
    )


@pytest.fixture()
def minimal_profile() -> FutureMeProfile:
    """Profile with only the required fields set."""
    return FutureMeProfile(name="Sam", time_horizon=1)


# ---------------------------------------------------------------------------
# generate_response — return type and basic structure
# ---------------------------------------------------------------------------


def test_generate_response_returns_string(bot, full_profile) -> None:
    result = bot.generate_response("How are you?", full_profile)
    assert isinstance(result, str)


def test_generate_response_is_not_empty(bot, full_profile) -> None:
    result = bot.generate_response("Tell me about yourself.", full_profile)
    assert len(result.strip()) > 0


# ---------------------------------------------------------------------------
# Topic routing
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("message", [
    "I feel like giving up on my goals.",
    "I have no motivation today.",
    "I am struggling with burnout.",
    "This is really difficult.",
])
def test_motivation_topic_triggered(bot, full_profile, message: str) -> None:
    result = bot.generate_response(message, full_profile)
    # Motivation responses should reference goals or values from the profile
    assert any(
        fragment in result
        for fragment in [
            full_profile.personal_goals,
            full_profile.values,
            str(full_profile.time_horizon),
            full_profile.name,
        ]
    )


@pytest.mark.parametrize("message", [
    "Tell me about your career.",
    "What is your job like?",
    "How is your work going?",
])
def test_career_topic_triggered(bot, full_profile, message: str) -> None:
    result = bot.generate_response(message, full_profile)
    assert full_profile.career_aspirations in result or "career" in result.lower()


@pytest.mark.parametrize("message", [
    "What are your goals?",
    "Tell me about your dreams.",
    "What do you aim for?",
])
def test_goals_topic_triggered(bot, full_profile, message: str) -> None:
    result = bot.generate_response(message, full_profile)
    assert full_profile.personal_goals in result or "goal" in result.lower()


# ---------------------------------------------------------------------------
# Profile data injected into responses
# ---------------------------------------------------------------------------


def test_response_contains_profile_name(bot, full_profile) -> None:
    result = bot.generate_response("Tell me about yourself.", full_profile)
    assert full_profile.name in result


def test_response_reflects_time_horizon(bot, full_profile) -> None:
    result = bot.generate_response("What is your future like?", full_profile)
    assert str(full_profile.time_horizon) in result


# ---------------------------------------------------------------------------
# Empty profile fields — graceful fallback
# ---------------------------------------------------------------------------


def test_empty_career_field_uses_fallback(bot, minimal_profile) -> None:
    result = bot.generate_response("Tell me about your career.", minimal_profile)
    # Should not raise; should return a non-empty string with a fallback phrase
    assert isinstance(result, str)
    assert len(result) > 0


def test_empty_goals_field_uses_fallback(bot, minimal_profile) -> None:
    result = bot.generate_response("What are your goals?", minimal_profile)
    assert isinstance(result, str)
    assert len(result) > 0


def test_all_empty_optional_fields_returns_response(bot, minimal_profile) -> None:
    result = bot.generate_response("I feel like quitting.", minimal_profile)
    assert isinstance(result, str)
    assert len(result) > 0


# ---------------------------------------------------------------------------
# Fallback / general topic
# ---------------------------------------------------------------------------


def test_unrecognised_message_returns_general_response(bot, full_profile) -> None:
    result = bot.generate_response(
        "Xylophone purple quantum flux blargh", full_profile
    )
    assert isinstance(result, str)
    assert len(result) > 0


def test_general_response_still_contains_name(bot, full_profile) -> None:
    result = bot.generate_response(
        "Xylophone purple quantum flux blargh", full_profile
    )
    assert full_profile.name in result


# ---------------------------------------------------------------------------
# Topic detection
# ---------------------------------------------------------------------------


def test_detect_topic_career(bot) -> None:
    assert bot._detect_topic("What is your career like?") == "career"


def test_detect_topic_motivation(bot) -> None:
    assert bot._detect_topic("I feel like giving up.") == "motivation"


def test_detect_topic_goals(bot) -> None:
    assert bot._detect_topic("What are your goals?") == "goals"


def test_detect_topic_habits(bot) -> None:
    assert bot._detect_topic("Tell me about your habits.") == "habits"


def test_detect_topic_default_for_unknown(bot) -> None:
    assert bot._detect_topic("Xylophone purple flux") == "general"


# ---------------------------------------------------------------------------
# Conversation continuity — multiple calls do not interfere
# ---------------------------------------------------------------------------


def test_multiple_calls_each_return_strings(bot, full_profile) -> None:
    messages = [
        "Tell me about your career.",
        "What motivates you?",
        "What are your habits?",
        "I feel like giving up.",
        "What do you value most?",
    ]
    for msg in messages:
        result = bot.generate_response(msg, full_profile)
        assert isinstance(result, str)
        assert len(result) > 0
