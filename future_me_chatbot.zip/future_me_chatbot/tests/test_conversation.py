"""Unit tests for conversation.py."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from conversation import Conversation, Message


# ---------------------------------------------------------------------------
# Message dataclass
# ---------------------------------------------------------------------------


def test_message_stores_role_and_content() -> None:
    m = Message(role="user", content="Hello")
    assert m.role == "user"
    assert m.content == "Hello"


# ---------------------------------------------------------------------------
# Conversation — basic operations
# ---------------------------------------------------------------------------


def test_new_conversation_is_empty() -> None:
    conv = Conversation()
    assert conv.is_empty() is True


def test_add_message_grows_history() -> None:
    conv = Conversation()
    conv.add_message("user", "Hi there")
    assert len(conv.get_history()) == 1


def test_add_multiple_messages_keeps_order() -> None:
    conv = Conversation()
    conv.add_message("user", "First")
    conv.add_message("assistant", "Second")
    conv.add_message("user", "Third")
    history = conv.get_history()
    assert history[0].content == "First"
    assert history[1].content == "Second"
    assert history[2].content == "Third"


def test_is_empty_false_after_adding_message() -> None:
    conv = Conversation()
    conv.add_message("user", "Hello")
    assert conv.is_empty() is False


def test_clear_empties_history() -> None:
    conv = Conversation()
    conv.add_message("user", "Hello")
    conv.add_message("assistant", "Hi")
    conv.clear()
    assert conv.is_empty() is True


def test_clear_on_empty_conversation_is_safe() -> None:
    conv = Conversation()
    conv.clear()  # should not raise
    assert conv.is_empty() is True


def test_get_history_returns_copy() -> None:
    """Mutating the returned list must not affect internal state."""
    conv = Conversation()
    conv.add_message("user", "Hello")
    history = conv.get_history()
    history.clear()
    assert not conv.is_empty()


# ---------------------------------------------------------------------------
# Serialisation round-trip
# ---------------------------------------------------------------------------


def test_to_list_returns_list_of_dicts() -> None:
    conv = Conversation()
    conv.add_message("user", "Hello")
    conv.add_message("assistant", "Hi there")
    data = conv.to_list()
    assert isinstance(data, list)
    assert data[0] == {"role": "user", "content": "Hello"}
    assert data[1] == {"role": "assistant", "content": "Hi there"}


def test_from_list_round_trip() -> None:
    conv = Conversation()
    conv.add_message("user", "Question")
    conv.add_message("assistant", "Answer")
    restored = Conversation.from_list(conv.to_list())
    assert len(restored.get_history()) == 2
    assert restored.get_history()[0].role == "user"
    assert restored.get_history()[1].content == "Answer"


def test_from_list_empty_list_creates_empty_conversation() -> None:
    conv = Conversation.from_list([])
    assert conv.is_empty() is True
