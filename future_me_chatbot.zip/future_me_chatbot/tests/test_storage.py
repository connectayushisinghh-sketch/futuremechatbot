"""Unit tests for storage.py — JSON persistence."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

from conversation import Conversation
from exceptions import StorageError
from profile import FutureMeProfile
import storage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_profile() -> FutureMeProfile:
    return FutureMeProfile(
        name="Alex",
        time_horizon=5,
        career_aspirations="Senior engineer",
        personal_goals="Run a marathon",
        habits="Daily reading",
        achievements="Launch a product",
        lifestyle="Remote work",
        values="Integrity",
        future_notes="Keep growing",
    )


# ---------------------------------------------------------------------------
# save_profile / load_profile
# ---------------------------------------------------------------------------


def test_save_profile_creates_file(tmp_path) -> None:
    path = tmp_path / "profile.json"
    p = _make_profile()
    storage.save_profile(p, path=path)
    assert path.exists()


def test_save_profile_writes_valid_json(tmp_path) -> None:
    path = tmp_path / "profile.json"
    p = _make_profile()
    storage.save_profile(p, path=path)
    data = json.loads(path.read_text())
    assert data["name"] == "Alex"


def test_load_profile_returns_correct_profile(tmp_path) -> None:
    path = tmp_path / "profile.json"
    p = _make_profile()
    storage.save_profile(p, path=path)
    loaded = storage.load_profile(path=path)
    assert loaded is not None
    assert loaded.name == "Alex"
    assert loaded.time_horizon == 5
    assert loaded.career_aspirations == "Senior engineer"


def test_load_profile_returns_none_when_file_absent(tmp_path) -> None:
    path = tmp_path / "nonexistent.json"
    result = storage.load_profile(path=path)
    assert result is None


def test_load_profile_raises_storage_error_on_invalid_json(tmp_path) -> None:
    path = tmp_path / "bad.json"
    path.write_text("NOT VALID JSON {{{", encoding="utf-8")
    with pytest.raises(StorageError):
        storage.load_profile(path=path)


def test_load_profile_raises_storage_error_on_missing_name_key(tmp_path) -> None:
    path = tmp_path / "bad.json"
    path.write_text(json.dumps({"time_horizon": 5}), encoding="utf-8")
    # Missing 'name' — from_dict will raise KeyError, wrapped into StorageError
    with pytest.raises(StorageError):
        storage.load_profile(path=path)


def test_save_and_load_round_trip(tmp_path) -> None:
    path = tmp_path / "profile.json"
    original = _make_profile()
    storage.save_profile(original, path=path)
    loaded = storage.load_profile(path=path)
    assert loaded is not None
    assert loaded.to_dict() == original.to_dict()


# ---------------------------------------------------------------------------
# delete_profile / profile_exists
# ---------------------------------------------------------------------------


def test_profile_exists_false_before_save(tmp_path) -> None:
    path = tmp_path / "profile.json"
    assert storage.profile_exists(path=path) is False


def test_profile_exists_true_after_save(tmp_path) -> None:
    path = tmp_path / "profile.json"
    storage.save_profile(_make_profile(), path=path)
    assert storage.profile_exists(path=path) is True


def test_delete_profile_removes_file(tmp_path) -> None:
    path = tmp_path / "profile.json"
    storage.save_profile(_make_profile(), path=path)
    storage.delete_profile(path=path)
    assert not path.exists()


def test_delete_profile_safe_when_file_absent(tmp_path) -> None:
    path = tmp_path / "nonexistent.json"
    storage.delete_profile(path=path)  # should not raise


def test_load_after_delete_returns_none(tmp_path) -> None:
    path = tmp_path / "profile.json"
    storage.save_profile(_make_profile(), path=path)
    storage.delete_profile(path=path)
    assert storage.load_profile(path=path) is None


# ---------------------------------------------------------------------------
# save_conversation / load_conversation
# ---------------------------------------------------------------------------


def test_save_conversation_creates_file(tmp_path) -> None:
    path = tmp_path / "conv.json"
    conv = Conversation()
    conv.add_message("user", "Hello")
    conv.add_message("assistant", "Hi there")
    storage.save_conversation(conv, path=path)
    assert path.exists()


def test_load_conversation_round_trip(tmp_path) -> None:
    path = tmp_path / "conv.json"
    conv = Conversation()
    conv.add_message("user", "Hello")
    conv.add_message("assistant", "Hi there")
    storage.save_conversation(conv, path=path)
    loaded = storage.load_conversation(path=path)
    history = loaded.get_history()
    assert len(history) == 2
    assert history[0].role == "user"
    assert history[0].content == "Hello"
    assert history[1].content == "Hi there"


def test_load_conversation_returns_empty_when_file_absent(tmp_path) -> None:
    path = tmp_path / "nonexistent.json"
    conv = storage.load_conversation(path=path)
    assert conv.is_empty()


def test_load_conversation_raises_on_invalid_json(tmp_path) -> None:
    path = tmp_path / "bad_conv.json"
    path.write_text("NOT JSON", encoding="utf-8")
    with pytest.raises(StorageError):
        storage.load_conversation(path=path)


def test_delete_conversation_removes_file(tmp_path) -> None:
    path = tmp_path / "conv.json"
    conv = Conversation()
    conv.add_message("user", "Hello")
    storage.save_conversation(conv, path=path)
    storage.delete_conversation(path=path)
    assert not path.exists()


def test_delete_conversation_safe_when_file_absent(tmp_path) -> None:
    path = tmp_path / "nonexistent.json"
    storage.delete_conversation(path=path)  # should not raise
