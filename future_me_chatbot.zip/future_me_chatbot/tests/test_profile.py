"""Unit tests for profile.py — FutureMeProfile data model."""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the app package directory is importable from the tests/ subdirectory.
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

from exceptions import InvalidTimeHorizonError
from profile import FutureMeProfile, VALID_HORIZONS


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


def test_profile_creates_with_minimum_fields() -> None:
    p = FutureMeProfile(name="Alex", time_horizon=5)
    assert p.name == "Alex"
    assert p.time_horizon == 5


def test_profile_creates_with_all_fields() -> None:
    p = FutureMeProfile(
        name="Jordan",
        time_horizon=10,
        career_aspirations="Lead engineer",
        personal_goals="Run a marathon",
        habits="Daily reading",
        achievements="Publish a book",
        lifestyle="Remote work",
        values="Integrity",
        future_notes="Keep learning",
    )
    assert p.career_aspirations == "Lead engineer"
    assert p.personal_goals == "Run a marathon"
    assert p.future_notes == "Keep learning"


def test_profile_defaults_optional_fields_to_empty_string() -> None:
    p = FutureMeProfile(name="Sam", time_horizon=1)
    assert p.career_aspirations == ""
    assert p.personal_goals == ""
    assert p.habits == ""
    assert p.achievements == ""
    assert p.lifestyle == ""
    assert p.values == ""
    assert p.future_notes == ""


def test_invalid_time_horizon_raises_error() -> None:
    with pytest.raises(InvalidTimeHorizonError):
        FutureMeProfile(name="Alex", time_horizon=3)


def test_zero_time_horizon_raises_error() -> None:
    with pytest.raises(InvalidTimeHorizonError):
        FutureMeProfile(name="Alex", time_horizon=0)


def test_negative_time_horizon_raises_error() -> None:
    with pytest.raises(InvalidTimeHorizonError):
        FutureMeProfile(name="Alex", time_horizon=-5)


@pytest.mark.parametrize("horizon", VALID_HORIZONS)
def test_all_valid_horizons_accepted(horizon: int) -> None:
    p = FutureMeProfile(name="Alex", time_horizon=horizon)
    assert p.time_horizon == horizon


# ---------------------------------------------------------------------------
# is_ready
# ---------------------------------------------------------------------------


def test_is_ready_true_with_name_and_valid_horizon() -> None:
    p = FutureMeProfile(name="Alex", time_horizon=5)
    assert p.is_ready() is True


def test_is_ready_false_with_empty_name() -> None:
    p = FutureMeProfile.__new__(FutureMeProfile)
    object.__setattr__(p, "name", "")
    object.__setattr__(p, "time_horizon", 5)
    object.__setattr__(p, "career_aspirations", "")
    object.__setattr__(p, "personal_goals", "")
    object.__setattr__(p, "habits", "")
    object.__setattr__(p, "achievements", "")
    object.__setattr__(p, "lifestyle", "")
    object.__setattr__(p, "values", "")
    object.__setattr__(p, "future_notes", "")
    assert p.is_ready() is False


def test_is_ready_false_with_whitespace_only_name() -> None:
    p = FutureMeProfile.__new__(FutureMeProfile)
    object.__setattr__(p, "name", "   ")
    object.__setattr__(p, "time_horizon", 5)
    object.__setattr__(p, "career_aspirations", "")
    object.__setattr__(p, "personal_goals", "")
    object.__setattr__(p, "habits", "")
    object.__setattr__(p, "achievements", "")
    object.__setattr__(p, "lifestyle", "")
    object.__setattr__(p, "values", "")
    object.__setattr__(p, "future_notes", "")
    assert p.is_ready() is False


# ---------------------------------------------------------------------------
# Serialisation round-trip
# ---------------------------------------------------------------------------


def test_to_dict_contains_all_keys() -> None:
    p = FutureMeProfile(name="Alex", time_horizon=5)
    d = p.to_dict()
    expected_keys = {
        "name", "time_horizon", "career_aspirations", "personal_goals",
        "habits", "achievements", "lifestyle", "values", "future_notes",
    }
    assert set(d.keys()) == expected_keys


def test_from_dict_round_trip() -> None:
    original = FutureMeProfile(
        name="Morgan",
        time_horizon=10,
        career_aspirations="Startup founder",
        personal_goals="Travel every continent",
        habits="Morning run",
        achievements="Launch a product",
        lifestyle="Nomadic",
        values="Freedom",
        future_notes="Never stop growing",
    )
    restored = FutureMeProfile.from_dict(original.to_dict())
    assert restored.name == original.name
    assert restored.time_horizon == original.time_horizon
    assert restored.career_aspirations == original.career_aspirations
    assert restored.personal_goals == original.personal_goals
    assert restored.habits == original.habits
    assert restored.achievements == original.achievements
    assert restored.lifestyle == original.lifestyle
    assert restored.values == original.values
    assert restored.future_notes == original.future_notes


def test_from_dict_missing_optional_fields_uses_defaults() -> None:
    data = {"name": "Riley", "time_horizon": 5}
    p = FutureMeProfile.from_dict(data)
    assert p.name == "Riley"
    assert p.career_aspirations == ""


def test_from_dict_invalid_horizon_raises_error() -> None:
    data = {"name": "Riley", "time_horizon": 7}
    with pytest.raises(InvalidTimeHorizonError):
        FutureMeProfile.from_dict(data)


# ---------------------------------------------------------------------------
# Profile editing (simulated by creating a new profile with updated fields)
# ---------------------------------------------------------------------------


def test_profile_edit_updates_fields() -> None:
    original = FutureMeProfile(name="Alex", time_horizon=5, personal_goals="Travel")
    updated = FutureMeProfile(
        name=original.name,
        time_horizon=original.time_horizon,
        personal_goals="Travel and write a book",
        career_aspirations=original.career_aspirations,
        habits=original.habits,
        achievements=original.achievements,
        lifestyle=original.lifestyle,
        values=original.values,
        future_notes=original.future_notes,
    )
    assert updated.personal_goals == "Travel and write a book"
    assert updated.name == "Alex"
