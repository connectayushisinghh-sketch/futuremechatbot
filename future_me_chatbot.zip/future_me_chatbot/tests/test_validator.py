"""Unit tests for validator.py."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

from profile import FutureMeProfile
from validator import (
    MAX_FIELD_LENGTH,
    MAX_MESSAGE_LENGTH,
    MAX_NAME_LENGTH,
    sanitize_text,
    validate_message,
    validate_profile,
)


# ---------------------------------------------------------------------------
# sanitize_text
# ---------------------------------------------------------------------------


def test_sanitize_strips_leading_whitespace() -> None:
    assert sanitize_text("   hello") == "hello"


def test_sanitize_strips_trailing_whitespace() -> None:
    assert sanitize_text("hello   ") == "hello"


def test_sanitize_strips_both_ends() -> None:
    assert sanitize_text("  hello world  ") == "hello world"


def test_sanitize_empty_string_stays_empty() -> None:
    assert sanitize_text("") == ""


# ---------------------------------------------------------------------------
# validate_profile
# ---------------------------------------------------------------------------


def _make_profile(**kwargs) -> FutureMeProfile:
    """Helper: build a valid profile, overriding fields via kwargs.

    Uses object.__setattr__ to bypass __post_init__ when injecting
    invalid values for testing.
    """
    p = FutureMeProfile.__new__(FutureMeProfile)
    defaults = dict(
        name="Alex",
        time_horizon=5,
        career_aspirations="",
        personal_goals="",
        habits="",
        achievements="",
        lifestyle="",
        values="",
        future_notes="",
    )
    defaults.update(kwargs)
    for k, v in defaults.items():
        object.__setattr__(p, k, v)
    return p


def test_validate_profile_passes_for_valid_profile() -> None:
    p = FutureMeProfile(name="Alex", time_horizon=5)
    is_valid, errors = validate_profile(p)
    assert is_valid is True
    assert errors == []


def test_validate_profile_fails_for_empty_name() -> None:
    p = _make_profile(name="")
    is_valid, errors = validate_profile(p)
    assert is_valid is False
    assert any("Name" in e for e in errors)


def test_validate_profile_fails_for_whitespace_only_name() -> None:
    p = _make_profile(name="   ")
    is_valid, errors = validate_profile(p)
    assert is_valid is False


def test_validate_profile_fails_for_name_too_long() -> None:
    p = _make_profile(name="A" * (MAX_NAME_LENGTH + 1))
    is_valid, errors = validate_profile(p)
    assert is_valid is False
    assert any("Name" in e for e in errors)


def test_validate_profile_accepts_name_at_max_length() -> None:
    p = _make_profile(name="A" * MAX_NAME_LENGTH)
    is_valid, _ = validate_profile(p)
    assert is_valid is True


def test_validate_profile_fails_for_invalid_time_horizon() -> None:
    p = _make_profile(time_horizon=99)
    is_valid, errors = validate_profile(p)
    assert is_valid is False
    assert any("horizon" in e.lower() for e in errors)


def test_validate_profile_fails_for_field_too_long() -> None:
    p = _make_profile(personal_goals="x" * (MAX_FIELD_LENGTH + 1))
    is_valid, errors = validate_profile(p)
    assert is_valid is False
    assert any("Personal goals" in e for e in errors)


def test_validate_profile_multiple_errors_returned() -> None:
    p = _make_profile(name="", time_horizon=99)
    is_valid, errors = validate_profile(p)
    assert is_valid is False
    assert len(errors) >= 2


# ---------------------------------------------------------------------------
# validate_message
# ---------------------------------------------------------------------------


def test_validate_message_passes_for_valid_message() -> None:
    is_valid, error = validate_message("Hello Future Me!")
    assert is_valid is True
    assert error == ""


def test_validate_message_fails_for_empty_string() -> None:
    is_valid, error = validate_message("")
    assert is_valid is False
    assert "empty" in error.lower()


def test_validate_message_fails_for_whitespace_only() -> None:
    is_valid, error = validate_message("    ")
    assert is_valid is False


def test_validate_message_fails_for_message_too_long() -> None:
    is_valid, error = validate_message("x" * (MAX_MESSAGE_LENGTH + 1))
    assert is_valid is False
    assert str(MAX_MESSAGE_LENGTH) in error


def test_validate_message_accepts_message_at_max_length() -> None:
    is_valid, _ = validate_message("x" * MAX_MESSAGE_LENGTH)
    assert is_valid is True
