"""Unit tests for ChatEngine."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from chat_engine import ChatEngine, TOPIC_KEYWORDS
from models import ChatMessage, FutureMeProfile


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def full_profile() -> FutureMeProfile:
    return FutureMeProfile(
        name="Alice",
        time_horizon=5,
        goals="Run a marathon and write a novel",
        career_aspirations="Lead software engineer at a tech startup",
        habits="Exercise every morning and meditate daily",
        achievements="Published a book and ran a 5K",
        lifestyle="Remote work and world travel",
        values="Integrity, growth, and kindness",
    )


@pytest.fixture()
def minimal_profile() -> FutureMeProfile:
    """Profile with only the required fields — all optional fields empty."""
    return FutureMeProfile(name="Bob", time_horizon=1)


@pytest.fixture()
def engine() -> ChatEngine:
    return ChatEngine()


# ---------------------------------------------------------------------------
# Topic detection
# ---------------------------------------------------------------------------

class TestDetectTopic:
    def test_motivation_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("I feel like giving up") == "motivation"

    def test_career_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("Tell me about your career") == "career"

    def test_goals_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("What are your goals?") == "goals"

    def test_habits_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("What habits do you have?") == "habits"

    def test_personal_growth_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("How did you grow as a person?") == "personal_growth"

    def test_achievements_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("What did you achieve?") == "achievements"

    def test_lifestyle_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("Describe your lifestyle") == "lifestyle"

    def test_values_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("What are your values?") == "values"

    def test_future_planning_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("What is your plan for the future?") == "future_planning"

    def test_identity_keyword(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("Who are you?") == "identity"

    def test_unknown_message_returns_default(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("xyzzy plugh foo bar") == "default"

    def test_case_insensitive(self, engine: ChatEngine) -> None:
        assert engine._detect_topic("CAREER advice please") == "career"


# ---------------------------------------------------------------------------
# Template filling
# ---------------------------------------------------------------------------

class TestFillTemplate:
    def test_returns_non_empty_string_for_every_topic(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        all_topics = list(TOPIC_KEYWORDS.keys()) + ["default"]
        for topic in all_topics:
            result = engine._fill_template(topic, full_profile)
            assert isinstance(result, str)
            assert len(result) > 0, f"Empty response for topic: {topic}"

    def test_uses_profile_name(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        result = engine._fill_template("identity", full_profile)
        assert "Alice" in result

    def test_uses_profile_goals(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        # Run multiple times to cover all random template choices.
        results = [engine._fill_template("goals", full_profile) for _ in range(20)]
        assert any("marathon" in r or "novel" in r for r in results)

    def test_uses_profile_career(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        results = [engine._fill_template("career", full_profile) for _ in range(20)]
        assert any("startup" in r or "engineer" in r for r in results)

    def test_fallback_phrase_when_goals_empty(
        self, engine: ChatEngine, minimal_profile: FutureMeProfile
    ) -> None:
        results = [engine._fill_template("goals", minimal_profile) for _ in range(20)]
        assert any("biggest goals" in r for r in results)

    def test_fallback_phrase_when_career_empty(
        self, engine: ChatEngine, minimal_profile: FutureMeProfile
    ) -> None:
        results = [engine._fill_template("career", minimal_profile) for _ in range(20)]
        assert any("career path" in r for r in results)

    def test_fallback_phrase_when_values_empty(
        self, engine: ChatEngine, minimal_profile: FutureMeProfile
    ) -> None:
        results = [engine._fill_template("values", minimal_profile) for _ in range(20)]
        assert any("matters most" in r for r in results)

    def test_unknown_topic_uses_default(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        result = engine._fill_template("nonexistent_topic", full_profile)
        assert isinstance(result, str)
        assert len(result) > 0


# ---------------------------------------------------------------------------
# generate_response (public method)
# ---------------------------------------------------------------------------

class TestGenerateResponse:
    def test_returns_chat_message(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        msg = engine.generate_response("Tell me about your career", full_profile)
        assert isinstance(msg, ChatMessage)

    def test_role_is_assistant(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        msg = engine.generate_response("What are your goals?", full_profile)
        assert msg.role == "assistant"

    def test_content_is_non_empty(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        msg = engine.generate_response("Hello!", full_profile)
        assert len(msg.content) > 0

    def test_motivation_response_contains_profile_data(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        results = [
            engine.generate_response("I feel like giving up", full_profile).content
            for _ in range(20)
        ]
        # At least one response should reference goals or values from profile.
        assert any(
            "marathon" in r or "novel" in r or "Integrity" in r or "Alice" in r
            for r in results
        )

    def test_career_response_contains_career_field(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        results = [
            engine.generate_response("How is your career going?", full_profile).content
            for _ in range(20)
        ]
        assert any("startup" in r or "engineer" in r for r in results)

    def test_response_with_minimal_profile_does_not_crash(
        self, engine: ChatEngine, minimal_profile: FutureMeProfile
    ) -> None:
        for topic_msg in [
            "I feel like giving up",
            "Tell me about your career",
            "What are your goals?",
            "What habits do you have?",
            "Who are you?",
        ]:
            msg = engine.generate_response(topic_msg, minimal_profile)
            assert len(msg.content) > 0

    def test_timestamp_is_set(
        self, engine: ChatEngine, full_profile: FutureMeProfile
    ) -> None:
        msg = engine.generate_response("Hello", full_profile)
        assert msg.timestamp  # non-empty string


# ---------------------------------------------------------------------------
# Conversation history model (ChatMessage)
# ---------------------------------------------------------------------------

class TestChatMessage:
    def test_create_user_message(self) -> None:
        msg = ChatMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"

    def test_create_assistant_message(self) -> None:
        msg = ChatMessage(role="assistant", content="Future me here!")
        assert msg.role == "assistant"

    def test_to_dict(self) -> None:
        msg = ChatMessage(role="user", content="Hi")
        d = msg.to_dict()
        assert d["role"] == "user"
        assert d["content"] == "Hi"
        assert "timestamp" in d

    def test_from_dict_roundtrip(self) -> None:
        msg = ChatMessage(role="assistant", content="Hello!")
        restored = ChatMessage.from_dict(msg.to_dict())
        assert restored.role == msg.role
        assert restored.content == msg.content
        assert restored.timestamp == msg.timestamp

    def test_clear_conversation(self) -> None:
        """Simulate clearing a conversation history list."""
        history: list[ChatMessage] = [
            ChatMessage(role="user", content="Hi"),
            ChatMessage(role="assistant", content="Hello!"),
        ]
        assert len(history) == 2
        history.clear()
        assert len(history) == 0
