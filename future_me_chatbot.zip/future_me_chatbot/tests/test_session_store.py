"""Unit tests for SessionStore."""

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from exceptions import StorageError
from models import FutureMeProfile
from session_store import SessionStore


@pytest.fixture()
def profile() -> FutureMeProfile:
    """A minimal valid profile for testing."""
    return FutureMeProfile(
        name="Alice",
        time_horizon=5,
        goals="Run a marathon",
        career_aspirations="Senior software engineer",
    )


@pytest.fixture()
def store(tmp_path: pytest.TempPathFactory) -> SessionStore:
    """A SessionStore pointed at a temp directory."""
    return SessionStore(filepath=str(tmp_path / "test_profile.json"))


class TestProfileExists:
    def test_returns_false_when_no_file(self, store: SessionStore) -> None:
        assert store.profile_exists() is False

    def test_returns_true_after_save(
        self, store: SessionStore, profile: FutureMeProfile
    ) -> None:
        store.save_profile(profile)
        assert store.profile_exists() is True


class TestSaveProfile:
    def test_file_is_created(
        self, store: SessionStore, profile: FutureMeProfile, tmp_path
    ) -> None:
        store.save_profile(profile)
        assert os.path.isfile(str(tmp_path / "test_profile.json"))

    def test_file_contains_valid_json(
        self, store: SessionStore, profile: FutureMeProfile, tmp_path
    ) -> None:
        store.save_profile(profile)
        with open(str(tmp_path / "test_profile.json"), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        assert data["name"] == "Alice"
        assert data["time_horizon"] == 5


class TestLoadProfile:
    def test_returns_none_when_no_file(self, store: SessionStore) -> None:
        assert store.load_profile() is None

    def test_roundtrip(
        self, store: SessionStore, profile: FutureMeProfile
    ) -> None:
        store.save_profile(profile)
        loaded = store.load_profile()
        assert loaded is not None
        assert loaded.name == profile.name
        assert loaded.time_horizon == profile.time_horizon
        assert loaded.goals == profile.goals
        assert loaded.career_aspirations == profile.career_aspirations

    def test_corrupt_json_raises_storage_error(
        self, store: SessionStore, tmp_path
    ) -> None:
        # Write invalid JSON to the file manually.
        path = str(tmp_path / "test_profile.json")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("{this is not valid json}")
        with pytest.raises(StorageError):
            store.load_profile()


class TestDeleteProfile:
    def test_delete_removes_file(
        self, store: SessionStore, profile: FutureMeProfile
    ) -> None:
        store.save_profile(profile)
        assert store.profile_exists() is True
        store.delete_profile()
        assert store.profile_exists() is False

    def test_delete_when_no_file_does_not_raise(self, store: SessionStore) -> None:
        store.delete_profile()  # should not raise
