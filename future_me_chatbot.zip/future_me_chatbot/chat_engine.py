"""Chatbot response engine for the Future Me Chatbot application.

ChatEngine generates responses from the user's stored Future Me profile
using a keyword-based topic detector and response templates.

Design note: ``generate_response`` is the single public method.
Its signature is intentionally stable so the rule-based engine can be
replaced with an AI API backend without changing any other module.
"""

from __future__ import annotations

import random
from datetime import datetime, timezone

from models import ChatMessage, FutureMeProfile


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Topic keyword map
# Each key is a topic name; each value is a list of trigger words/phrases.
# ---------------------------------------------------------------------------

TOPIC_KEYWORDS: dict[str, list[str]] = {
    "motivation": [
        "give up", "giving up", "quit", "quitting", "can't do", "cannot do",
        "discouraged", "hopeless", "unmotivated", "no motivation", "struggling",
        "hard time", "difficult", "lost", "stuck", "fail", "failing",
        "inspire", "motivate", "push me", "encourage",
    ],
    "career": [
        "career", "job", "work", "profession", "business", "industry",
        "employer", "employee", "salary", "promotion", "office", "company",
        "professional", "occupation", "role", "position",
    ],
    "goals": [
        "goal", "goals", "dream", "dreams", "aim", "objective", "target",
        "milestone", "aspiration", "ambition", "vision", "purpose",
    ],
    "habits": [
        "habit", "habits", "routine", "discipline", "practice", "daily",
        "morning", "evening", "ritual", "consistency", "schedule",
    ],
    "personal_growth": [
        "grow", "growth", "improve", "improvement", "learn", "learning",
        "develop", "development", "change", "progress", "better",
        "mindset", "skill", "skills", "knowledge",
    ],
    "achievements": [
        "achieve", "achievement", "achievements", "accomplish", "accomplished",
        "success", "successful", "proud", "milestone", "done", "completed",
        "win", "winning",
    ],
    "lifestyle": [
        "lifestyle", "life", "balance", "home", "travel", "living",
        "health", "fitness", "family", "social", "hobby", "hobbies",
        "free time", "weekend", "vacation",
    ],
    "values": [
        "value", "values", "belief", "beliefs", "principle", "principles",
        "faith", "priority", "priorities", "integrity", "ethics", "morals",
        "important to you", "what matters",
    ],
    "future_planning": [
        "future", "plan for", "planning", "next year", "years from now",
        "long term", "short term", "where will", "where are you",
        "what will", "by when", "roadmap",
    ],
    "identity": [
        "who are you", "who am i", "tell me about yourself", "introduce",
        "describe yourself", "what are you like", "your story",
    ],
}

# ---------------------------------------------------------------------------
# Response templates
# Placeholders: {name}, {time_horizon}, and one profile field per topic.
# ---------------------------------------------------------------------------

RESPONSE_TEMPLATES: dict[str, list[str]] = {
    "motivation": [
        "I know exactly how you feel right now — I've been there. "
        "But let me tell you: {goals_or_default} is completely worth every hard day. "
        "Every moment you pushed through became part of who I am today. Keep going.",

        "Future {name} here. There were days I wanted to quit too. "
        "What kept me going was remembering {values_or_default}. "
        "One difficult day does not define your future. You've got this.",

        "Struggling right now is part of the process. In {time_horizon} year(s) "
        "you will look back at this exact moment and be glad you did not give up. "
        "Hold on to {goals_or_default} — it is worth every bit of the effort.",
    ],
    "career": [
        "In {time_horizon} year(s) from now, I have made real progress toward "
        "{career_or_default}. The consistency you show today is exactly what got me here. "
        "Trust the journey.",

        "My career path led me toward {career_or_default}. "
        "I put in the work, stayed focused, and the doors started opening. "
        "You are already on the right track, {name}.",

        "Looking back from {time_horizon} year(s) ahead, every career decision "
        "you are wrestling with right now will make sense. "
        "Keep building toward {career_or_default} — it is your north star.",
    ],
    "goals": [
        "Your future self has been working hard on {goals_or_default}. "
        "Every small step you take today is one more brick in the foundation. "
        "Stay consistent, {name}.",

        "In {time_horizon} year(s) you will have made serious progress on "
        "{goals_or_default}. The version of you that achieves it is built "
        "from the choices you make right now.",

        "{goals_or_default} is what drives me forward every day. "
        "Don't underestimate how much the small daily actions matter. "
        "They add up to everything.",
    ],
    "habits": [
        "One of the biggest changes in my life was building the habit of "
        "{habits_or_default}. Consistency over {time_horizon} year(s) "
        "transforms small actions into a whole new identity.",

        "In {time_horizon} year(s) {habits_or_default} will feel completely "
        "natural — because you kept showing up even when it was hard. "
        "Start small, stay consistent, {name}.",

        "The routines you build today become the foundation of who you are tomorrow. "
        "{habits_or_default} will become second nature before you know it.",
    ],
    "personal_growth": [
        "Personal growth takes time, but {time_horizon} year(s) from now "
        "you will barely recognise how much you have changed — in the best way. "
        "Keep learning, {name}.",

        "The investment you make in yourself now pays compounding dividends. "
        "Trust the process. Every skill, every lesson, every failure — "
        "they all matter and they are all working for you.",

        "Future {name} here: you are going to look back at who you are today "
        "and feel proud of how much you grew. Stay curious and keep pushing forward.",
    ],
    "achievements": [
        "By the time {time_horizon} year(s) have passed, I have accomplished "
        "{achievements_or_default}. It was not easy, but it was worth everything.",

        "Every achievement starts with deciding that it is possible. "
        "{achievements_or_default} is something your future self is genuinely proud of. "
        "You are building toward it right now.",

        "I am so proud of what I have accomplished — especially {achievements_or_default}. "
        "Future {name} is proof that the work you are putting in today pays off.",
    ],
    "lifestyle": [
        "In {time_horizon} year(s) I am living {lifestyle_or_default}. "
        "The choices you make about how you spend your time right now are "
        "shaping that reality.",

        "The life I have built — {lifestyle_or_default} — is a direct result "
        "of the intentional decisions you are making today, {name}. "
        "Keep prioritising what matters.",

        "Lifestyle is built one decision at a time. "
        "In {time_horizon} year(s) those decisions will add up to "
        "{lifestyle_or_default}. Stay focused on the life you want.",
    ],
    "values": [
        "At my core, what guides me is {values_or_default}. "
        "Those values have been my compass through every major decision "
        "over the past {time_horizon} year(s).",

        "When things get hard, come back to {values_or_default}. "
        "Your future self still stands on those same principles — "
        "they are the foundation of everything you build.",

        "{values_or_default} has shaped every important choice I have made. "
        "Knowing what you stand for is one of the greatest gifts you can give yourself.",
    ],
    "future_planning": [
        "Looking {time_horizon} year(s) ahead, the most important thing is "
        "to start now. The plans you make and the steps you take today "
        "compound into something remarkable.",

        "Future {name} here. My advice: write down your goals, break them into "
        "steps, and take one action every day. {time_horizon} year(s) from now "
        "you will be astonished by the result.",

        "Planning is everything. Every day you invest in {goals_or_default} "
        "is a day closer to the life you are designing. "
        "Keep your eyes on the {time_horizon}-year vision.",
    ],
    "identity": [
        "I'm {name}, {time_horizon} year(s) into the journey you are on right now. "
        "I've grown through challenges, celebrated wins, and stayed true to "
        "{values_or_default}. I am proof of what is possible for you.",

        "Future {name} here! I am the version of you who kept going. "
        "I built {goals_or_default} and worked toward {career_or_default}. "
        "Everything you are doing today is making me possible.",

        "Think of me as your guide. I am {name}, {time_horizon} year(s) from now. "
        "I made the choices, did the work, and became the person we always wanted to be.",
    ],
    "default": [
        "That is a great question, {name}. From {time_horizon} year(s) in the future, "
        "I can tell you that the journey is absolutely worth it. "
        "Keep asking questions — curiosity is one of your greatest strengths.",

        "Future {name} here! Whatever you are thinking about right now, "
        "trust yourself. You have more capacity for growth than you realise. "
        "The work you do today shapes who I am.",

        "I hear you, {name}. Every question you ask, every step you take — "
        "they all matter. In {time_horizon} year(s) you will see exactly how far "
        "you have come. Keep going.",
    ],
}


class ChatEngine:
    """Generates Future Me responses using keyword topic detection and templates.

    The single public method ``generate_response`` accepts a user message
    and the current profile, returning a ``ChatMessage`` with role='assistant'.

    This stable interface means the rule-based engine can be swapped for an
    AI API backend by replacing only this class.
    """

    def generate_response(
        self, message: str, profile: FutureMeProfile
    ) -> ChatMessage:
        """Generate a Future Me response to the given user message.

        Args:
            message: The user's input text.
            profile: The current ``FutureMeProfile`` to personalise the response.

        Returns:
            A ``ChatMessage`` with ``role='assistant'``.
        """
        topic = self._detect_topic(message)
        content = self._fill_template(topic, profile)
        return ChatMessage(role="assistant", content=content)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_topic(message: str) -> str:
        """Scan the message for keywords and return the best-matching topic.

        Returns ``'default'`` when no keyword matches.
        """
        lower = message.lower()
        for topic, keywords in TOPIC_KEYWORDS.items():
            for kw in keywords:
                if kw in lower:
                    return topic
        return "default"

    @staticmethod
    def _fill_template(topic: str, profile: FutureMeProfile) -> str:
        """Pick a random template for the topic and fill it with profile data."""
        templates = RESPONSE_TEMPLATES.get(topic, RESPONSE_TEMPLATES["default"])
        template = random.choice(templates)

        # Build graceful fallbacks for each profile field.
        substitutions = {
            "name": profile.name or "Friend",
            "time_horizon": profile.time_horizon,
            "goals_or_default": profile.goals or "my biggest goals",
            "career_or_default": profile.career_aspirations or "my career path",
            "habits_or_default": profile.habits or "the habits that serve me",
            "achievements_or_default": profile.achievements or "the things I am most proud of",
            "lifestyle_or_default": profile.lifestyle or "the life I have built",
            "values_or_default": profile.values or "what matters most to me",
        }

        return template.format(**substitutions)
