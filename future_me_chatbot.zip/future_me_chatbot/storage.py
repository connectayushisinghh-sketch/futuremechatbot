"""JSON-based local persistence for the Future Me profile and conversation."""

from __future__ import annotations

import json
from pathlib import Path

from conversation import Conversation
from exceptions import StorageError
from profile import FutureMeProfile

DEFAULT_PROFILE_PATH: Path = Path("future_me_profile.json")
DEFAULT_CONVERSATION_PATH: Path = Path("future_me_conversation.json")


# ---------------------------------------------------------------------------
# Profile persistence
# ---------------------------------------------------------------------------


def save_profile(
    profile: FutureMeProfile,
    path: Path = DEFAULT_PROFILE_PATH,
) -> None:
    """Serialise and write a FutureMeProfile to a JSON file.

    Args:
        profile: The profile to save.
        path: Destination file path (default: ``future_me_profile.json``).

    Raises:
        StorageError: If the file cannot be written.
    """
    try:
        path.write_text(json.dumps(profile.to_dict(), indent=2), encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"Could not save profile to {path}: {exc}") from exc


def load_profile(path: Path = DEFAULT_PROFILE_PATH) -> FutureMeProfile | None:
    """Read and deserialise a FutureMeProfile from a JSON file.

    Args:
        path: Source file path (default: ``future_me_profile.json``).

    Returns:
        A FutureMeProfile instance, or None if the file does not exist.

    Raises:
        StorageError: If the file exists but contains invalid data.
    """
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return FutureMeProfile.from_dict(data)
    except json.JSONDecodeError as exc:
        raise StorageError(f"Profile file {path} contains invalid JSON: {exc}") from exc
    except (KeyError, TypeError, ValueError) as exc:
        raise StorageError(f"Profile file {path} has unexpected data: {exc}") from exc


def delete_profile(path: Path = DEFAULT_PROFILE_PATH) -> None:
    """Remove the profile JSON file if it exists.

    Args:
        path: File path to remove (default: ``future_me_profile.json``).
    """
    if path.exists():
        path.unlink()


def profile_exists(path: Path = DEFAULT_PROFILE_PATH) -> bool:
    """Return True when a saved profile file is present.

    Args:
        path: File path to check (default: ``future_me_profile.json``).
    """
    return path.exists()


# ---------------------------------------------------------------------------
# Conversation persistence
# ---------------------------------------------------------------------------


def save_conversation(
    conversation: Conversation,
    path: Path = DEFAULT_CONVERSATION_PATH,
) -> None:
    """Serialise and write conversation history to a JSON file.

    Args:
        conversation: The conversation to save.
        path: Destination file path (default: ``future_me_conversation.json``).

    Raises:
        StorageError: If the file cannot be written.
    """
    try:
        path.write_text(
            json.dumps(conversation.to_list(), indent=2), encoding="utf-8"
        )
    except OSError as exc:
        raise StorageError(
            f"Could not save conversation to {path}: {exc}"
        ) from exc


def load_conversation(
    path: Path = DEFAULT_CONVERSATION_PATH,
) -> Conversation:
    """Read and deserialise conversation history from a JSON file.

    Args:
        path: Source file path (default: ``future_me_conversation.json``).

    Returns:
        A Conversation instance.  Returns an empty Conversation if the file
        does not exist.

    Raises:
        StorageError: If the file exists but contains invalid data.
    """
    if not path.exists():
        return Conversation()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return Conversation.from_list(data)
    except json.JSONDecodeError as exc:
        raise StorageError(
            f"Conversation file {path} contains invalid JSON: {exc}"
        ) from exc
    except (KeyError, TypeError) as exc:
        raise StorageError(
            f"Conversation file {path} has unexpected data: {exc}"
        ) from exc


def delete_conversation(path: Path = DEFAULT_CONVERSATION_PATH) -> None:
    """Remove the conversation JSON file if it exists.

    Args:
        path: File path to remove (default: ``future_me_conversation.json``).
    """
    if path.exists():
        path.unlink()
