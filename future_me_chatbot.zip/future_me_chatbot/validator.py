"""Input validation for profile fields and chat messages."""

from __future__ import annotations

from profile import FutureMeProfile, VALID_HORIZONS

MAX_NAME_LENGTH: int = 50
MAX_FIELD_LENGTH: int = 500
MAX_MESSAGE_LENGTH: int = 500


def sanitize_text(text: str) -> str:
    """Strip leading and trailing whitespace from a string."""
    return text.strip()


def validate_profile(profile: FutureMeProfile) -> tuple[bool, list[str]]:
    """Validate a FutureMeProfile and return a result with error messages.

    Args:
        profile: The profile instance to validate.

    Returns:
        A tuple of (is_valid, errors) where errors is a list of human-readable
        strings describing every problem found.  The list is empty when valid.
    """
    errors: list[str] = []

    # Name
    if not profile.name.strip():
        errors.append("Name is required.")
    elif len(profile.name.strip()) > MAX_NAME_LENGTH:
        errors.append(f"Name must be {MAX_NAME_LENGTH} characters or fewer.")

    # Time horizon
    if profile.time_horizon not in VALID_HORIZONS:
        errors.append(f"Time horizon must be one of {VALID_HORIZONS}.")

    # Optional long-text fields
    long_text_fields = {
        "Career aspirations": profile.career_aspirations,
        "Personal goals": profile.personal_goals,
        "Habits": profile.habits,
        "Achievements": profile.achievements,
        "Lifestyle": profile.lifestyle,
        "Values": profile.values,
        "Future notes": profile.future_notes,
    }
    for label, value in long_text_fields.items():
        if len(value) > MAX_FIELD_LENGTH:
            errors.append(
                f"{label} must be {MAX_FIELD_LENGTH} characters or fewer."
            )

    return len(errors) == 0, errors


def validate_message(text: str) -> tuple[bool, str]:
    """Validate a chat message before it is sent.

    Args:
        text: The raw message text entered by the user.

    Returns:
        A tuple of (is_valid, error_message).  error_message is an empty
        string when the message is valid.
    """
    stripped = text.strip()

    if not stripped:
        return False, "Message cannot be empty."

    if len(stripped) > MAX_MESSAGE_LENGTH:
        return False, f"Message must be {MAX_MESSAGE_LENGTH} characters or fewer."

    return True, ""
