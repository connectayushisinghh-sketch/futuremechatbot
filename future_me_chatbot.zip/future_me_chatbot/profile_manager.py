"""Profile management for the Future Me Chatbot application.

Contains:
- FutureMeProfile: re-exported here for convenience (defined in models.py).
- ProfileManager: orchestrates validation, creation, editing, and persistence.
"""

from __future__ import annotations

from datetime import datetime, timezone

from exceptions import ValidationError
from models import FutureMeProfile
from session_store import SessionStore
from validator import Validator

# Re-export so callers can do: from profile import FutureMeProfile
__all__ = ["FutureMeProfile", "ProfileManager"]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class ProfileManager:
    """Manages the lifecycle of a FutureMeProfile.

    Coordinates validation (via Validator) and persistence (via SessionStore).
    Contains no I/O or UI logic itself.

    Args:
        store: A ``SessionStore`` instance. Defaults to the standard store
            (writing to the project-root JSON file). Pass a custom store
            in unit tests.
    """

    def __init__(self, store: SessionStore | None = None) -> None:
        self._store = store or SessionStore()

    # ------------------------------------------------------------------
    # Profile creation
    # ------------------------------------------------------------------

    def create_profile(
        self,
        name: str,
        time_horizon: int,
        goals: str = "",
        career_aspirations: str = "",
        habits: str = "",
        achievements: str = "",
        lifestyle: str = "",
        values: str = "",
        notes: str = "",
    ) -> FutureMeProfile:
        """Validate fields and create a new FutureMeProfile.

        Raises:
            ValidationError: If any required or text field is invalid.
            InvalidTimeHorizonError: If time_horizon is not in {1, 5, 10}.
        """
        self._validate_all_fields(
            name, time_horizon, goals, career_aspirations,
            habits, achievements, lifestyle, values, notes,
        )
        return FutureMeProfile(
            name=name.strip(),
            time_horizon=time_horizon,
            goals=goals.strip(),
            career_aspirations=career_aspirations.strip(),
            habits=habits.strip(),
            achievements=achievements.strip(),
            lifestyle=lifestyle.strip(),
            values=values.strip(),
            notes=notes.strip(),
        )

    # ------------------------------------------------------------------
    # Profile editing
    # ------------------------------------------------------------------

    def update_profile(
        self,
        profile: FutureMeProfile,
        name: str,
        time_horizon: int,
        goals: str = "",
        career_aspirations: str = "",
        habits: str = "",
        achievements: str = "",
        lifestyle: str = "",
        values: str = "",
        notes: str = "",
    ) -> FutureMeProfile:
        """Validate new field values and apply them to an existing profile.

        The ``created_at`` timestamp is preserved; ``updated_at`` is refreshed.

        Raises:
            ValidationError: If any field is invalid.
            InvalidTimeHorizonError: If time_horizon is not in {1, 5, 10}.
        """
        self._validate_all_fields(
            name, time_horizon, goals, career_aspirations,
            habits, achievements, lifestyle, values, notes,
        )
        profile.name = name.strip()
        profile.time_horizon = time_horizon
        profile.goals = goals.strip()
        profile.career_aspirations = career_aspirations.strip()
        profile.habits = habits.strip()
        profile.achievements = achievements.strip()
        profile.lifestyle = lifestyle.strip()
        profile.values = values.strip()
        profile.notes = notes.strip()
        profile.updated_at = _now_iso()
        return profile

    # ------------------------------------------------------------------
    # Persistence delegation
    # ------------------------------------------------------------------

    def save(self, profile: FutureMeProfile) -> None:
        """Persist the profile to disk via the store."""
        self._store.save_profile(profile)

    def load(self) -> FutureMeProfile | None:
        """Load and return the profile from disk, or None if absent."""
        return self._store.load_profile()

    def reset(self) -> None:
        """Delete the persisted profile from disk."""
        self._store.delete_profile()

    def profile_exists(self) -> bool:
        """Return True if a profile is saved on disk."""
        return self._store.profile_exists()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_all_fields(
        name: str,
        time_horizon: int,
        goals: str,
        career_aspirations: str,
        habits: str,
        achievements: str,
        lifestyle: str,
        values: str,
        notes: str,
    ) -> None:
        Validator.validate_name(name)
        Validator.validate_time_horizon(time_horizon)
        Validator.validate_text_field(goals, "goals")
        Validator.validate_text_field(career_aspirations, "career_aspirations")
        Validator.validate_text_field(habits, "habits")
        Validator.validate_text_field(achievements, "achievements")
        Validator.validate_text_field(lifestyle, "lifestyle")
        Validator.validate_text_field(values, "values")
        Validator.validate_text_field(notes, "notes")
