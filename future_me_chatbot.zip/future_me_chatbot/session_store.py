"""Local JSON persistence for the Future Me Chatbot application.

SessionStore handles all file I/O. No other module reads or writes files.
The storage file path is configurable so unit tests can use a temp directory.
"""

import json
import os
from pathlib import Path

from exceptions import StorageError
from models import FutureMeProfile

# Default profile file location — sits in the project root directory.
DEFAULT_PROFILE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "future_me_profile.json"
)


class SessionStore:
    """Reads and writes the Future Me profile to a local JSON file.

    Args:
        filepath: Path to the JSON file. Defaults to ``future_me_profile.json``
            in the project directory. Pass a custom path in tests.
    """

    def __init__(self, filepath: str = DEFAULT_PROFILE_PATH) -> None:
        self._filepath = filepath

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def save_profile(self, profile: FutureMeProfile) -> None:
        """Serialise and write the profile to the JSON file.

        Raises:
            StorageError: If the file cannot be written.
        """
        try:
            with open(self._filepath, "w", encoding="utf-8") as fh:
                json.dump(profile.to_dict(), fh, indent=2, ensure_ascii=False)
        except OSError as exc:
            raise StorageError(
                f"Could not write profile to {self._filepath!r}: {exc}"
            ) from exc

    def load_profile(self) -> FutureMeProfile | None:
        """Read and deserialise the profile from the JSON file.

        Returns:
            A ``FutureMeProfile`` if the file exists and is valid,
            or ``None`` if the file does not exist.

        Raises:
            StorageError: If the file exists but contains invalid JSON.
        """
        if not self.profile_exists():
            return None
        try:
            with open(self._filepath, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return FutureMeProfile.from_dict(data)
        except json.JSONDecodeError as exc:
            raise StorageError(
                f"Profile file {self._filepath!r} contains invalid JSON: {exc}"
            ) from exc
        except OSError as exc:
            raise StorageError(
                f"Could not read profile from {self._filepath!r}: {exc}"
            ) from exc

    def delete_profile(self) -> None:
        """Remove the profile JSON file.

        Does nothing if the file does not exist.

        Raises:
            StorageError: If the file exists but cannot be deleted.
        """
        if not self.profile_exists():
            return
        try:
            Path(self._filepath).unlink()
        except OSError as exc:
            raise StorageError(
                f"Could not delete profile file {self._filepath!r}: {exc}"
            ) from exc

    def profile_exists(self) -> bool:
        """Return True if the profile JSON file exists on disk."""
        return Path(self._filepath).is_file()
