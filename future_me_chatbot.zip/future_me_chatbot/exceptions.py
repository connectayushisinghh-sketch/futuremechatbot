"""Custom exceptions for the Future Me Chatbot application."""


class FutureMeError(Exception):
    """Base exception for all Future Me Chatbot errors."""
    pass


class ProfileNotReadyError(FutureMeError):
    """Raised when a chat is attempted before a valid profile exists."""
    pass


class EmptyMessageError(FutureMeError):
    """Raised when the user attempts to send an empty chat message."""
    pass


class InvalidTimeHorizonError(FutureMeError):
    """Raised when the time horizon value is not one of [1, 5, 10]."""
    pass


class ValidationError(FutureMeError):
    """Raised when a profile field fails validation.

    Attributes:
        field: The name of the field that failed validation.
        message: A human-readable description of the error.
    """

    def __init__(self, field: str, message: str) -> None:
        self.field = field
        self.message = message
        super().__init__(f"{field}: {message}")


class StorageError(FutureMeError):
    """Raised when reading from or writing to the JSON profile file fails."""
    pass
