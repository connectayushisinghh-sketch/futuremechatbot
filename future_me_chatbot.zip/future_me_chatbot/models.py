"""Data models for the Future Me Chatbot application.

Contains:
- FutureMeProfile: dataclass representing the user's future self profile.
- ChatMessage: dataclass representing a single message in the conversation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


def _now_iso() -> str:
    """Return the current UTC time as an ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()


@dataclass
class FutureMeProfile:
    """The user's Future Me profile.

    Required fields: name, time_horizon.
    All other fields are optional and default to an empty string.
    """

    name: str
    time_horizon: int
    goals: str = ""
    career_aspirations: str = ""
    habits: str = ""
    achievements: str = ""
    lifestyle: str = ""
    values: str = ""
    notes: str = ""
    created_at: str = field(default_factory=_now_iso)
    updated_at: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, Any]:
        """Serialise the profile to a plain dictionary for JSON storage."""
        return {
            "name": self.name,
            "time_horizon": self.time_horizon,
            "goals": self.goals,
            "career_aspirations": self.career_aspirations,
            "habits": self.habits,
            "achievements": self.achievements,
            "lifestyle": self.lifestyle,
            "values": self.values,
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FutureMeProfile":
        """Deserialise a profile from a dictionary.

        Missing optional keys are replaced with their defaults so that
        older stored profiles remain loadable after new fields are added.
        """
        return cls(
            name=data.get("name", ""),
            time_horizon=data.get("time_horizon", 5),
            goals=data.get("goals", ""),
            career_aspirations=data.get("career_aspirations", ""),
            habits=data.get("habits", ""),
            achievements=data.get("achievements", ""),
            lifestyle=data.get("lifestyle", ""),
            values=data.get("values", ""),
            notes=data.get("notes", ""),
            created_at=data.get("created_at", _now_iso()),
            updated_at=data.get("updated_at", _now_iso()),
        )

    def is_complete(self) -> bool:
        """Return True if the minimum required fields are populated."""
        return bool(self.name.strip()) and self.time_horizon in {1, 5, 10}


@dataclass
class ChatMessage:
    """A single message in the conversation.

    Attributes:
        role: Either "user" or "assistant".
        content: The text of the message.
        timestamp: ISO 8601 UTC timestamp set at creation.
    """

    role: str
    content: str
    timestamp: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, str]:
        """Serialise the message to a plain dictionary."""
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ChatMessage":
        """Deserialise a message from a dictionary."""
        return cls(
            role=data.get("role", "user"),
            content=data.get("content", ""),
            timestamp=data.get("timestamp", _now_iso()),
        )
