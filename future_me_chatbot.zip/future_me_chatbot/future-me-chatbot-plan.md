# Future Me Chatbot — Implementation Plan

## Top-Level Overview

**Goal:** Build a beginner-friendly, educational chatbot application in Python using Streamlit where a user creates a "Future Me" profile and converses with their future self.

**Scope:**
- Five focused Python modules with clean separation of concerns
- Rule/template-based response engine designed with a swappable interface
- JSON-based local persistence (save/load profile to disk)
- Streamlit single-page UI with profile and chat sections
- pytest unit tests covering business logic (not the UI)

**Non-Goals:**
- No authentication, databases, cloud services, or external AI APIs
- No multi-user support
- No persistent conversation history across sessions

**Technology:** Python 3.10+, Streamlit, pytest, standard library only (json, pathlib, dataclasses)

---

## Application Architecture

```
future_me_chatbot/
├── app.py                  # Streamlit UI entry point
├── profile.py              # FutureMeProfile data class + serialisation
├── chatbot.py              # FutureMeChatbot response engine (swappable)
├── conversation.py         # Conversation model (message history)
├── validator.py            # Input validation helpers
├── exceptions.py           # Custom application exceptions
├── storage.py              # JSON save/load helpers
└── tests/
    ├── test_profile.py
    ├── test_chatbot.py
    ├── test_conversation.py
    ├── test_validator.py
    └── test_storage.py
```

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold

**Intent:** Create the folder structure, empty module files, and project configuration so that every subsequent sub-task has a clean place to work.

**Expected Outcomes:**
- All directories and empty `.py` files exist
- `requirements.txt` lists `streamlit` and `pytest`
- `README.md` contains a one-paragraph description and run instructions

**Todo List:**
1. Create `future_me_chatbot/` root folder
2. Create empty files: `app.py`, `profile.py`, `chatbot.py`, `conversation.py`, `validator.py`, `exceptions.py`, `storage.py`
3. Create `tests/` subdirectory with empty test files and `__init__.py`
4. Create `requirements.txt` with `streamlit` and `pytest`
5. Create `README.md` with project description and `streamlit run app.py` instructions

**Relevant Context:** None — greenfield project.

**Status:** [ ] pending

---

### Sub-Task 2 — Custom Exceptions

**Intent:** Define all custom exceptions in one place so other modules can import them without circular dependencies.

**Expected Outcomes:**
- `exceptions.py` defines three exception classes
- All exceptions inherit from a single base `FutureMeError`

**Todo List:**
1. Define `FutureMeError(Exception)` as the base class
2. Define `ProfileNotReadyError(FutureMeError)` — raised when chat is attempted without a valid profile
3. Define `EmptyMessageError(FutureMeError)` — raised when the user sends a blank chat message
4. Define `InvalidTimeHorizonError(FutureMeError)` — raised when time horizon is not in [1, 5, 10]

**Relevant Context:** `exceptions.py`

**Status:** [ ] pending

---

### Sub-Task 3 — FutureMeProfile Data Model

**Intent:** Implement the profile data class that holds all user-entered future profile information and can be serialised to/from a plain dict for JSON storage.

**Expected Outcomes:**
- `FutureMeProfile` is a Python `dataclass` with all required fields
- `to_dict()` returns a plain dict representation
- `from_dict()` is a `@classmethod` that reconstructs a profile from a dict
- `is_ready()` returns `True` only when `name` is non-empty and `time_horizon` is valid
- `InvalidTimeHorizonError` is raised in the constructor if `time_horizon` is invalid

**Todo List:**
1. Import `dataclass`, `field` from `dataclasses`; import `InvalidTimeHorizonError`
2. Define `VALID_HORIZONS = [1, 5, 10]` as a module-level constant
3. Define `FutureMeProfile` as a `@dataclass` with fields:
   - `name: str`
   - `goals: str = ""`
   - `career_aspirations: str = ""`
   - `habits: str = ""`
   - `achievements: str = ""`
   - `lifestyle: str = ""`
   - `values: str = ""`
   - `time_horizon: int = 5`
4. Add `__post_init__` to validate `time_horizon` and raise `InvalidTimeHorizonError` if invalid
5. Implement `is_ready(self) -> bool`
6. Implement `to_dict(self) -> dict`
7. Implement `from_dict(cls, data: dict) -> FutureMeProfile` as a classmethod

**Relevant Context:** `profile.py`, `exceptions.py`

**Status:** [ ] pending

---

### Sub-Task 4 — Input Validator

**Intent:** Centralise all input validation so that both the UI and tests can call the same rules.

**Expected Outcomes:**
- `validate_profile(profile)` returns a tuple `(bool, list[str])` — is_valid flag and list of human-readable error messages
- `sanitize_text(text)` strips leading/trailing whitespace and collapses internal newlines
- `validate_message(text)` returns `(bool, str)` — is_valid and error message

**Todo List:**
1. Import `FutureMeProfile` from `profile.py`
2. Implement `sanitize_text(text: str) -> str` — strip whitespace only (no HTML escaping needed)
3. Implement `validate_profile(profile: FutureMeProfile) -> tuple[bool, list[str]]`:
   - Name must be non-empty after stripping
   - Name must be 50 characters or fewer
   - Time horizon must be in `[1, 5, 10]`
4. Implement `validate_message(text: str) -> tuple[bool, str]`:
   - Must be non-empty after stripping
   - Must be 500 characters or fewer

**Relevant Context:** `validator.py`, `profile.py`

**Status:** [ ] pending

---

### Sub-Task 5 — Conversation Model

**Intent:** Implement a simple in-memory conversation history store that can be managed independently of the chatbot logic.

**Expected Outcomes:**
- `Message` is a `dataclass` with `role: str` and `content: str`
- `Conversation` manages an ordered list of `Message` objects
- History can be added to, read, and cleared
- `to_list()` returns a plain list of dicts (for session state serialisation)

**Todo List:**
1. Define `Message` as a `@dataclass` with `role: str` and `content: str`
2. Define `Conversation` class with `_messages: list[Message]` as instance variable
3. Implement `add_message(self, role: str, content: str)` — appends a new `Message`
4. Implement `get_history(self) -> list[Message]` — returns a copy of the message list
5. Implement `clear(self)` — empties the message list
6. Implement `is_empty(self) -> bool`
7. Implement `to_list(self) -> list[dict]` — converts each Message to `{"role": ..., "content": ...}`
8. Implement `from_list(cls, data: list[dict]) -> Conversation` as a classmethod

**Relevant Context:** `conversation.py`

**Status:** [ ] pending

---

### Sub-Task 6 — Chatbot Response Engine

**Intent:** Implement the rule/template-based response engine behind a clean abstract interface, so the engine can later be swapped for an AI-backed implementation without touching the UI or other modules.

**Expected Outcomes:**
- `BaseChatbot` abstract base class defines the single public method contract: `generate_response(user_message, profile) -> str`
- `RuleBasedChatbot` implements `BaseChatbot` using keyword detection + response templates
- Responses always speak in first person as the future self
- Responses acknowledge missing profile fields gracefully
- The `time_horizon` is always reflected in the response phrasing

**Todo List:**
1. Import `ABC`, `abstractmethod` from `abc`; import `FutureMeProfile` from `profile.py`
2. Define `BaseChatbot(ABC)` with abstract method `generate_response(self, user_message: str, profile: FutureMeProfile) -> str`
3. Define `TOPIC_KEYWORDS` dict mapping topic names to lists of trigger keywords:
   - `"career"`: `["career", "job", "work", "profession", "occupation"]`
   - `"goals"`: `["goal", "dream", "aim", "plan", "aspire"]`
   - `"habits"`: `["habit", "routine", "practice", "discipline", "daily"]`
   - `"achievements"`: `["achieve", "accomplish", "milestone", "success"]`
   - `"lifestyle"`: `["lifestyle", "live", "balance", "day", "life"]`
   - `"values"`: `["value", "believe", "principle", "important", "matter"]`
   - `"identity"`: `["who are you", "tell me about", "introduce", "describe yourself"]`
4. Define `RESPONSE_TEMPLATES` dict mapping topic names to template strings using `{name}`, `{years}`, `{field}` placeholders
5. Define fallback template for unmatched input
6. Implement `_detect_topic(self, message: str) -> str | None` — lowercased keyword scan, returns first matched topic or `None`
7. Implement `_get_field_for_topic(self, topic: str, profile: FutureMeProfile) -> str` — returns the relevant profile field string
8. Implement `_build_response(self, topic: str | None, profile: FutureMeProfile) -> str` — selects template, injects profile data, handles empty fields
9. Implement `generate_response(self, user_message: str, profile: FutureMeProfile) -> str` — orchestrates detection → build → return

**Response Template Examples (for reference during implementation):**
- career: `"In {years} year(s), I'm proud to say I've pursued {field}. The path wasn't easy, but staying focused made all the difference."`
- fallback: `"That's a thoughtful question. In {years} year(s), I've learned so much — what specifically would you like to know about my journey, {name}?"`
- empty field fallback: `"I haven't fully defined that part of my future yet — but that's something worth thinking about!"`

**Relevant Context:** `chatbot.py`, `profile.py`

**Status:** [ ] pending

---

### Sub-Task 7 — Local Persistence (JSON Storage)

**Intent:** Implement save and load helpers that persist the profile to a local JSON file, so the user can close and reopen the app without losing their profile.

**Expected Outcomes:**
- `save_profile(profile, path)` writes profile to a JSON file
- `load_profile(path)` reads and returns a `FutureMeProfile`, or `None` if the file does not exist
- Storage is isolated from all other business logic — only `storage.py` touches the filesystem

**Todo List:**
1. Import `json`, `pathlib.Path`; import `FutureMeProfile` from `profile.py`
2. Define `DEFAULT_PROFILE_PATH = Path("future_me_profile.json")` as module constant
3. Implement `save_profile(profile: FutureMeProfile, path: Path = DEFAULT_PROFILE_PATH) -> None` — writes `profile.to_dict()` as formatted JSON
4. Implement `load_profile(path: Path = DEFAULT_PROFILE_PATH) -> FutureMeProfile | None` — reads JSON and calls `FutureMeProfile.from_dict()`, returns `None` if file not found or JSON is invalid
5. Implement `delete_profile(path: Path = DEFAULT_PROFILE_PATH) -> None` — removes the file if it exists (used for profile reset)

**Relevant Context:** `storage.py`, `profile.py`

**Status:** [ ] pending

---

### Sub-Task 8 — Streamlit UI

**Intent:** Build the user-facing Streamlit application that wires all business logic modules together into a working web UI.

**Expected Outcomes:**
- App launches with `streamlit run app.py`
- Profile form collects all fields and validates before saving
- Chat interface is disabled until a valid profile exists
- Chat messages display in order with clear role labelling ("You" / "Future Me")
- Sidebar or expander shows profile details at a glance
- All actions (save, load, clear chat, reset profile) work correctly
- Session state is used for profile and conversation; no business logic lives in `app.py`

**Todo List:**
1. Import all modules: `profile`, `chatbot`, `conversation`, `validator`, `storage`, `exceptions`
2. Initialise `st.session_state` keys on first load: `"profile"`, `"conversation"`, `"chatbot_engine"`
3. Attempt `storage.load_profile()` on first load and populate session state if a saved profile exists
4. Build **Profile Section** (use `st.form` or `st.expander`):
   - Text input for name
   - Text areas for goals, career aspirations, habits, achievements, lifestyle, values
   - Selectbox for time horizon `[1, 5, 10]`
   - "Save Profile" button — validates, saves to JSON, updates session state
   - "Reset Profile" button — deletes JSON file, clears session state profile and conversation
5. Build **Chat Section** (disabled/hidden if profile not ready):
   - Display conversation history using `st.chat_message` (or manual layout)
   - `st.chat_input` for new user messages
   - On submit: validate message → add to conversation → generate response → add response to conversation
   - "Clear Conversation" button
6. Add sidebar showing current profile summary (name, time horizon, which fields are filled)
7. Show success/error/info `st.toast` or `st.info` messages for user feedback

**Relevant Context:** `app.py`, all other modules

**Status:** [ ] pending

---

### Sub-Task 9 — Unit Tests

**Intent:** Write pytest unit tests for all business logic modules to confirm correctness of the core domain independently of the UI.

**Expected Outcomes:**
- Tests exist for `profile.py`, `chatbot.py`, `conversation.py`, `validator.py`, `storage.py`
- All tests pass with `pytest tests/`
- No test touches the Streamlit UI

**Todo List:**

**`tests/test_profile.py`:**
1. Test `FutureMeProfile` creates successfully with valid data
2. Test `is_ready()` returns `True` with name set, `False` without
3. Test `InvalidTimeHorizonError` raised for invalid horizon
4. Test `to_dict()` / `from_dict()` round-trip

**`tests/test_validator.py`:**
5. Test `validate_profile()` passes with name + valid horizon
6. Test `validate_profile()` fails with empty name
7. Test `validate_profile()` fails with name over 50 chars
8. Test `validate_message()` fails for empty string
9. Test `validate_message()` fails for message over 500 chars
10. Test `sanitize_text()` strips whitespace

**`tests/test_conversation.py`:**
11. Test `add_message()` grows history
12. Test `clear()` empties history
13. Test `to_list()` / `from_list()` round-trip
14. Test `is_empty()` returns correct value

**`tests/test_chatbot.py`:**
15. Test `generate_response()` returns a string for a career-related message
16. Test `generate_response()` returns a fallback for an unrecognised message
17. Test response contains the profile name
18. Test response reflects the time horizon
19. Test response handles empty profile fields gracefully

**`tests/test_storage.py`:**
20. Test `save_profile()` creates a JSON file (use `tmp_path` fixture)
21. Test `load_profile()` returns the correct profile after save
22. Test `load_profile()` returns `None` when file does not exist
23. Test `delete_profile()` removes the file

**Relevant Context:** `tests/` directory, all business logic modules

**Status:** [ ] pending

---

## Data Model

```
FutureMeProfile
├── name: str                    (required)
├── goals: str                   (optional)
├── career_aspirations: str      (optional)
├── habits: str                  (optional)
├── achievements: str            (optional)
├── lifestyle: str               (optional)
├── values: str                  (optional)
└── time_horizon: int            (required; one of 1, 5, 10)

Message
├── role: str                    ("user" or "assistant")
└── content: str

Conversation
└── _messages: list[Message]
```

---

## Response Generation Strategy

The `RuleBasedChatbot` follows this pipeline:

1. **Normalise** — lowercase the user message
2. **Detect topic** — scan for keyword matches using `TOPIC_KEYWORDS`
3. **Retrieve field** — map topic → profile field value
4. **Select template** — choose from `RESPONSE_TEMPLATES[topic]`; use empty-field fallback if field is blank
5. **Inject values** — substitute `{name}`, `{years}`, `{field}` in the template string
6. **Return** — return the final response string

The `BaseChatbot` ABC ensures that swapping in an `AIChatbot` in the future only requires implementing `generate_response(user_message, profile) -> str`.

---

## Data Flow

```
User fills Profile Form
        │
        ▼
validator.validate_profile(profile)
        │
   valid? Yes ──► storage.save_profile(profile)
                         │
                         ▼
               st.session_state["profile"] = profile

User types chat message
        │
        ▼
validator.validate_message(message)
        │
   valid? Yes ──► conversation.add_message("user", message)
                         │
                         ▼
               chatbot.generate_response(message, profile)
                         │
                         ▼
               conversation.add_message("assistant", response)
                         │
                         ▼
               UI re-renders conversation history
```

---

## Local Persistence Strategy

- Profile is saved as `future_me_profile.json` in the working directory
- File is written on every "Save Profile" action
- File is read once on app startup to pre-populate the form
- File is deleted on "Reset Profile"
- Conversation history is NOT persisted — session state only

---

## Validation Strategy

| Location | What is validated |
|---|---|
| `validator.validate_profile()` | Called before saving profile |
| `validator.validate_message()` | Called before sending a chat message |
| `FutureMeProfile.__post_init__()` | Raises exception for invalid time horizon at construction time |
| UI | Shows user-friendly error messages returned by validator |

---

## Exception Handling Strategy

| Exception | Where raised | Where caught |
|---|---|---|
| `ProfileNotReadyError` | `app.py` guard before chat | `app.py` — show `st.error()` |
| `EmptyMessageError` | `app.py` message validation | `app.py` — show `st.warning()` |
| `InvalidTimeHorizonError` | `FutureMeProfile.__post_init__` | `app.py` save handler — show `st.error()` |
| `json.JSONDecodeError` | `storage.load_profile()` | `storage.load_profile()` — return `None` silently |
| `FileNotFoundError` | `storage.load_profile()` | `storage.load_profile()` — return `None` silently |

---

## Implementation Sequence

Sub-tasks are ordered so each one only depends on previously completed sub-tasks:

```
1. Project Scaffold
       │
       ▼
2. Custom Exceptions
       │
       ▼
3. FutureMeProfile (depends on exceptions)
       │
       ├──► 4. Validator (depends on profile)
       │
       ├──► 5. Conversation (independent)
       │
       ├──► 6. Chatbot Engine (depends on profile)
       │
       └──► 7. Storage (depends on profile)
                    │
                    ▼
             8. Streamlit UI (depends on all above)
                    │
                    ▼
             9. Unit Tests (tests all modules)
```
