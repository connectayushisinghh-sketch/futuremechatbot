# Future Me Chatbot

A beginner-friendly educational chatbot built with Python and Streamlit.

Create a **Future Me** profile describing your goals, career aspirations, habits, values, and desired lifestyle. Then start a conversation with your future self — the chatbot responds in character using your profile.

## Project Structure

```
future_me_chatbot/
├── app.py              # Streamlit UI entry point
├── profile.py          # FutureMeProfile data model
├── chatbot.py          # Rule-based response engine (swappable)
├── conversation.py     # In-memory conversation history
├── validator.py        # Input validation
├── exceptions.py       # Custom exceptions
├── storage.py          # JSON file persistence
├── requirements.txt
└── tests/
    ├── test_profile.py
    ├── test_chatbot.py
    ├── test_conversation.py
    ├── test_validator.py
    └── test_storage.py
```

## Setup

```bash
cd future_me_chatbot
pip install -r requirements.txt
```

## Run

```bash
streamlit run app.py
```

## Test

```bash
pytest tests/
```

## How It Works

1. Fill in your **Future Me Profile** — name, time horizon, career goals, habits, values, etc.
2. Save the profile (stored as `future_me_profile.json` locally).
3. Switch to the **Chat** tab and start a conversation.
4. Future Me responds using the information from your profile.
5. You can edit your profile, clear the conversation, or reset everything at any time.
