"""FutureMeProfile data model with serialisation support."""

from __future__ import annotations

from dataclasses import dataclass, field

from exceptions import InvalidTimeHorizonError

VALID_HORIZONS: list[int] = [1, 5, 10]


@dataclass
class FutureMeProfile:
    """Holds all user-entered Future Me profile information.

    Only ``name`` and ``time_horizon`` are required.  All other fields are
    optional free-text entries and default to an empty string.

    Raises:
        InvalidTimeHorizonError: If ``time_horizon`` is not in VALID_HORIZONS.
    """

    name: str
    time_horizon: int = 5
    career_aspirations: str = ""
    personal_goals: str = ""
    habits: str = ""
    achievements: str = ""
    lifestyle: str = ""
    values: str = ""
    future_notes: str = ""

    def __post_init__(self) -> None:
        if self.time_horizon not in VALID_HORIZONS:
            raise InvalidTimeHorizonError(
                f"time_horizon must be one of {VALID_HORIZONS}, "
                f"got {self.time_horizon!r}."
            )

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def is_ready(self) -> bool:
        """Return True when the profile has the minimum required data."""
        return bool(self.name.strip()) and self.time_horizon in VALID_HORIZONS

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialise the profile to a plain dictionary suitable for JSON."""
        return {
            "name": self.name,
            "time_horizon": self.time_horizon,
            "career_aspirations": self.career_aspirations,
            "personal_goals": self.personal_goals,
            "habits": self.habits,
            "achievements": self.achievements,
            "lifestyle": self.lifestyle,
            "values": self.values,
            "future_notes": self.future_notes,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FutureMeProfile":
        """Reconstruct a FutureMeProfile from a plain dictionary.

        Args:
            data: A dictionary as produced by ``to_dict()``.

        Returns:
            A new FutureMeProfile instance.

        Raises:
            InvalidTimeHorizonError: If the stored time_horizon is invalid.
            KeyError: If a required key is missing from ``data``.
        """
        return cls(
            name=data["name"],
            time_horizon=int(data.get("time_horizon", 5)),
            career_aspirations=data.get("career_aspirations", ""),
            personal_goals=data.get("personal_goals", ""),
            habits=data.get("habits", ""),
            achievements=data.get("achievements", ""),
            lifestyle=data.get("lifestyle", ""),
            values=data.get("values", ""),
            future_notes=data.get("future_notes", ""),
        )
