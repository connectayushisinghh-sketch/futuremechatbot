"""Future Me Chatbot — Streamlit application entry point.

Run with:
    streamlit run app.py

All business logic lives in the imported modules.  This file only handles
UI layout, session state initialisation, and wiring user actions to the
appropriate business logic calls.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

# ---------------------------------------------------------------------------
# Make sure the app directory is on sys.path when launched from outside it.
# ---------------------------------------------------------------------------
_APP_DIR = Path(__file__).parent
if str(_APP_DIR) not in sys.path:
    sys.path.insert(0, str(_APP_DIR))

from chatbot import RuleBasedChatbot          # noqa: E402
from conversation import Conversation          # noqa: E402
from exceptions import ProfileNotReadyError, StorageError  # noqa: E402
from profile import FutureMeProfile, VALID_HORIZONS        # noqa: E402
import storage                                 # noqa: E402
import validator                               # noqa: E402

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="Future Me Chatbot",
    page_icon="🚀",
    layout="centered",
)

# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------


def _init_session_state() -> None:
    """Populate session state keys on first load."""
    if "profile" not in st.session_state:
        # Try to load a previously saved profile.
        try:
            st.session_state["profile"] = storage.load_profile()
        except StorageError:
            st.session_state["profile"] = None

    if "conversation" not in st.session_state:
        try:
            st.session_state["conversation"] = storage.load_conversation()
        except StorageError:
            st.session_state["conversation"] = Conversation()

    if "chatbot" not in st.session_state:
        st.session_state["chatbot"] = RuleBasedChatbot()


_init_session_state()

# ---------------------------------------------------------------------------
# Sidebar — profile summary
# ---------------------------------------------------------------------------


def _render_sidebar() -> None:
    profile: FutureMeProfile | None = st.session_state["profile"]
    with st.sidebar:
        st.title("🚀 Future Me")
        if profile and profile.is_ready():
            st.success(f"Profile active: **{profile.name}**")
            st.markdown(f"⏱ **Time horizon:** {profile.time_horizon} year(s)")
            fields = {
                "Career aspirations": profile.career_aspirations,
                "Personal goals": profile.personal_goals,
                "Habits": profile.habits,
                "Achievements": profile.achievements,
                "Lifestyle": profile.lifestyle,
                "Values": profile.values,
                "Future notes": profile.future_notes,
            }
            filled = [k for k, v in fields.items() if v.strip()]
            empty = [k for k, v in fields.items() if not v.strip()]
            if filled:
                st.markdown("**✅ Filled fields:**")
                for f in filled:
                    st.markdown(f"- {f}")
            if empty:
                st.markdown("**⬜ Empty fields:**")
                for f in empty:
                    st.markdown(f"- {f}")
        else:
            st.info("No profile yet. Create one in the **Profile** tab.")

        st.divider()
        st.caption("A simple educational chatbot project.\nBuilt with Python & Streamlit.")


_render_sidebar()

# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------

tab_profile, tab_chat, tab_about = st.tabs(["👤 Profile", "💬 Chat", "ℹ️ About"])

# ===========================================================================
# TAB 1 — Profile
# ===========================================================================


def _profile_form(existing: FutureMeProfile | None) -> None:
    """Render the create/edit profile form."""
    defaults = existing if existing else FutureMeProfile(name="", time_horizon=5)

    with st.form("profile_form"):
        st.subheader("My Future Me Profile")

        name = st.text_input(
            "Your name *",
            value=defaults.name,
            placeholder="e.g. Alex",
            help="Required. This is how Future Me will address you.",
        )

        time_horizon = st.selectbox(
            "Time horizon *",
            options=VALID_HORIZONS,
            index=VALID_HORIZONS.index(defaults.time_horizon)
                  if defaults.time_horizon in VALID_HORIZONS else 1,
            format_func=lambda y: f"{y} year{'s' if y != 1 else ''}",
            help="How far into the future is your Future Me?",
        )

        career_aspirations = st.text_area(
            "Career aspirations",
            value=defaults.career_aspirations,
            placeholder="e.g. Become a senior software engineer at a tech company I admire.",
            height=90,
        )

        personal_goals = st.text_area(
            "Personal goals",
            value=defaults.personal_goals,
            placeholder="e.g. Run a half-marathon, travel to Japan, write a novel.",
            height=90,
        )

        habits = st.text_area(
            "Habits to develop",
            value=defaults.habits,
            placeholder="e.g. Daily exercise, reading 30 minutes a night, journaling.",
            height=90,
        )

        achievements = st.text_area(
            "Things I want to achieve",
            value=defaults.achievements,
            placeholder="e.g. Launch my own side project, pay off my student loan.",
            height=90,
        )

        lifestyle = st.text_area(
            "Desired future lifestyle",
            value=defaults.lifestyle,
            placeholder="e.g. Work remotely, live near the ocean, have a healthy work-life balance.",
            height=90,
        )

        values = st.text_area(
            "Important personal values",
            value=defaults.values,
            placeholder="e.g. Integrity, family, continuous learning, creativity.",
            height=90,
        )

        future_notes = st.text_area(
            "Additional future notes",
            value=defaults.future_notes,
            placeholder="Anything else about your future self you'd like the chatbot to know.",
            height=90,
        )

        col_save, col_reset = st.columns([3, 1])
        with col_save:
            save_clicked = st.form_submit_button(
                "💾 Save Profile", use_container_width=True, type="primary"
            )
        with col_reset:
            reset_clicked = st.form_submit_button(
                "🗑 Reset", use_container_width=True
            )

    # ---- Handle Save -------------------------------------------------------
    if save_clicked:
        try:
            profile = FutureMeProfile(
                name=validator.sanitize_text(name),
                time_horizon=int(time_horizon),
                career_aspirations=validator.sanitize_text(career_aspirations),
                personal_goals=validator.sanitize_text(personal_goals),
                habits=validator.sanitize_text(habits),
                achievements=validator.sanitize_text(achievements),
                lifestyle=validator.sanitize_text(lifestyle),
                values=validator.sanitize_text(values),
                future_notes=validator.sanitize_text(future_notes),
            )
        except Exception as exc:
            st.error(f"Could not create profile: {exc}")
            return

        is_valid, errors = validator.validate_profile(profile)
        if not is_valid:
            for error in errors:
                st.error(error)
            return

        try:
            storage.save_profile(profile)
        except StorageError as exc:
            st.error(f"Failed to save profile: {exc}")
            return

        st.session_state["profile"] = profile
        st.success("✅ Profile saved!")
        st.rerun()

    # ---- Handle Reset ------------------------------------------------------
    if reset_clicked:
        storage.delete_profile()
        storage.delete_conversation()
        st.session_state["profile"] = None
        st.session_state["conversation"] = Conversation()
        st.info("Profile and conversation have been reset.")
        st.rerun()


with tab_profile:
    _profile_form(st.session_state["profile"])

# ===========================================================================
# TAB 2 — Chat
# ===========================================================================


with tab_chat:
    profile: FutureMeProfile | None = st.session_state["profile"]
    conversation: Conversation = st.session_state["conversation"]
    chatbot: RuleBasedChatbot = st.session_state["chatbot"]

    if not profile or not profile.is_ready():
        st.info("👈 Create your **Future Me Profile** first, then come back to chat!")
    else:
        st.subheader(f"💬 Chatting with Future {profile.name}")
        st.caption(
            f"You are speaking with yourself **{profile.time_horizon} year(s)** from now."
        )

        # Clear conversation button
        if not conversation.is_empty():
            if st.button("🗑 Clear Conversation", key="clear_conv"):
                conversation.clear()
                storage.delete_conversation()
                st.rerun()

        # Render conversation history
        for msg in conversation.get_history():
            if msg.role == "user":
                with st.chat_message("user"):
                    st.markdown(msg.content)
            else:
                with st.chat_message("assistant", avatar="🚀"):
                    st.markdown(msg.content)

        # Chat input
        user_input = st.chat_input(
            f"Ask Future {profile.name} anything…",
            key="chat_input",
        )

        if user_input is not None:
            is_valid, error_msg = validator.validate_message(user_input)
            if not is_valid:
                st.warning(error_msg)
            else:
                # Add user message
                conversation.add_message("user", user_input.strip())

                # Generate and add assistant response
                try:
                    response = chatbot.generate_response(user_input.strip(), profile)
                except Exception as exc:
                    response = (
                        f"I'm sorry, I had trouble forming a response just now. "
                        f"({exc})"
                    )
                conversation.add_message("assistant", response)

                # Persist conversation
                try:
                    storage.save_conversation(conversation)
                except StorageError:
                    pass  # Non-fatal; conversation still lives in session state.

                st.rerun()

# ===========================================================================
# TAB 3 — About
# ===========================================================================

with tab_about:
    st.subheader("About Future Me Chatbot")
    st.markdown(
        """
**Future Me Chatbot** is a simple educational Python project that lets you
have a conversation with an imagined future version of yourself.

### How it works

1. **Create a profile** — fill in your name, future time horizon, career
   aspirations, personal goals, habits, values, and more.
2. **Start chatting** — type a message to your Future Me.
3. **Get a response** — the chatbot detects the topic of your message
   (motivation, career, goals, habits, etc.) and replies using the
   information from your profile.
4. **Edit anytime** — update your profile and the chatbot immediately
   uses the new information.

### Response engine

The chatbot uses a **rule-based keyword detection** system.  It scans your
message for topic keywords, selects a matching response template, and fills
in your profile data.  No external AI API is used.

The response engine is designed behind a clean interface (`BaseChatbot`)
so it can later be replaced with an AI-powered version without changing
any other part of the application.

### Data storage

Your profile and conversation history are saved locally as JSON files:
- `future_me_profile.json`
- `future_me_conversation.json`

No data is sent anywhere. Everything stays on your machine.
        """
    )
