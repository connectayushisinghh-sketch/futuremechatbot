"""Future Me chatbot response engine.

Architecture
------------
``BaseChatbot`` defines the single public contract:
    generate_response(user_message, profile) -> str

``RuleBasedChatbot`` implements this contract using keyword detection and
response templates.  To swap in an AI API later, create a new class that
inherits from ``BaseChatbot`` and implements ``generate_response`` — no
other module needs to change.
"""

from __future__ import annotations

import random
from abc import ABC, abstractmethod

from profile import FutureMeProfile

# ---------------------------------------------------------------------------
# Topic keyword map
# ---------------------------------------------------------------------------
# Keys are topic names.  Values are lists of trigger words/phrases that, when
# found (as substrings) in the lowercased user message, activate that topic.
# Topics are checked in the order defined here; the first match wins.
# ---------------------------------------------------------------------------

TOPIC_KEYWORDS: dict[str, list[str]] = {
    "motivation": [
        "give up", "giving up", "quit", "quitting", "can't do", "cannot do",
        "feel like failing", "feel like quitting", "hopeless", "discouraged",
        "demotivated", "unmotivated", "lost motivation", "no motivation",
        "struggling", "hard time", "difficult", "tough", "tired of",
        "worn out", "burned out", "burnout",
    ],
    "career": [
        "career", "job", "work", "profession", "occupation", "employed",
        "employment", "industry", "salary", "promotion", "boss", "colleague",
        "office", "business", "company", "startup", "freelance",
    ],
    "goals": [
        "goal", "dream", "aim", "objective", "target", "aspire", "aspiration",
        "wish", "hope", "desire", "ambition", "plan", "future plan",
    ],
    "habits": [
        "habit", "routine", "discipline", "practice", "daily", "morning",
        "evening", "schedule", "consistency", "consistent", "regular",
        "workout", "exercise", "meditate", "meditation", "reading",
    ],
    "achievements": [
        "achieve", "accomplish", "success", "proud", "milestone", "win",
        "done", "finished", "completed", "reached", "hit a goal",
        "celebrate", "celebration",
    ],
    "lifestyle": [
        "lifestyle", "life", "live", "balance", "home", "travel",
        "adventure", "health", "healthy", "wellbeing", "well-being",
        "happiness", "happy", "joy", "peace", "peaceful", "freedom",
    ],
    "values": [
        "value", "believe", "belief", "principle", "important", "matter",
        "priority", "integrity", "honesty", "kindness", "compassion",
        "faith", "purpose", "meaning",
    ],
    "personal_growth": [
        "grow", "growth", "improve", "improvement", "better", "learn",
        "learning", "skill", "knowledge", "develop", "development",
        "change", "transform", "transformation", "evolve", "progress",
    ],
    "future_planning": [
        "future", "plan", "planning", "years from now", "long term",
        "long-term", "next year", "next decade", "road map", "roadmap",
        "vision", "where will", "where do you see", "picture",
    ],
    "identity": [
        "who are you", "tell me about yourself", "introduce yourself",
        "describe yourself", "who is", "what are you like",
    ],
}

# ---------------------------------------------------------------------------
# Response templates
# ---------------------------------------------------------------------------
# Each topic maps to a list of template strings.  One is chosen at random
# each time so the bot does not feel repetitive.
#
# Placeholders:
#   {name}    — profile.name
#   {years}   — profile.time_horizon
#   {career}  — profile.career_aspirations (or fallback phrase)
#   {goals}   — profile.personal_goals (or fallback phrase)
#   {habits}  — profile.habits (or fallback phrase)
#   {achievements} — profile.achievements (or fallback phrase)
#   {lifestyle}    — profile.lifestyle (or fallback phrase)
#   {values}  — profile.values (or fallback phrase)
# ---------------------------------------------------------------------------

RESPONSE_TEMPLATES: dict[str, list[str]] = {
    "motivation": [
        "I hear you, {name}. There were many days I wanted to quit too. "
        "But I kept thinking about {goals}, and that gave me the strength "
        "to keep going. One hard day does not erase all your progress.",

        "Remember why you started, {name}. In {years} year(s), you'll look "
        "back at this moment and be so glad you didn't give up. "
        "The version of you that achieves {goals} is built in moments like this one.",

        "Difficult moments are part of the journey. {name}, the things I care about "
        "— {values} — are worth fighting for. Take a breath, then take the next step.",
    ],
    "career": [
        "In {years} year(s), I have been building toward {career}. "
        "Every skill you develop today is one I am grateful for now. "
        "Keep showing up.",

        "Your career path is already taking shape, {name}. "
        "Staying focused on {career} will make all the difference "
        "in {years} year(s) time.",

        "I worked hard on {career} and it paid off. "
        "Stay curious, keep learning, and trust that the effort compounds over time.",
    ],
    "goals": [
        "Your goals are the compass that guides every decision, {name}. "
        "In {years} year(s), I can tell you that pursuing {goals} was "
        "absolutely worth it.",

        "Don't lose sight of {goals}. They are the reason I am where I am "
        "{years} year(s) from now. Break them into smaller steps and start today.",

        "Every day you work toward {goals} is a day well spent. "
        "Future You is counting on Present You to keep the momentum going.",
    ],
    "habits": [
        "The habits you build now define the life you live in {years} year(s). "
        "I made {habits} a non-negotiable part of my day, and it changed everything.",

        "Consistency is the secret, {name}. Small daily actions around {habits} "
        "compound into remarkable results over {years} year(s).",

        "I am so glad Past Me committed to {habits}. "
        "Start small, stay consistent, and trust the process.",
    ],
    "achievements": [
        "In {years} year(s), I look back with pride at {achievements}. "
        "You are already on that path — keep going.",

        "Every step you take moves you closer to {achievements}. "
        "Celebrate your small wins along the way, {name}.",

        "The things I have accomplished — {achievements} — started exactly where "
        "you are right now. Believe in the process.",
    ],
    "lifestyle": [
        "In {years} year(s), I live {lifestyle}. "
        "The choices you make today are building that life piece by piece.",

        "The lifestyle you envision — {lifestyle} — is attainable, {name}. "
        "Align your daily actions with the life you want.",

        "Every intentional choice you make now gets me closer to {lifestyle}. "
        "Keep your vision clear.",
    ],
    "values": [
        "My values — {values} — have been my anchor through every challenge. "
        "When in doubt, come back to what matters most to you.",

        "In {years} year(s), I still live by {values}. "
        "Let them guide your decisions, especially the difficult ones.",

        "Your values are your true north, {name}. "
        "Decisions aligned with {values} rarely lead you astray.",
    ],
    "personal_growth": [
        "Growth is uncomfortable, {name}. But in {years} year(s), "
        "I am a completely different person — more capable, more confident, "
        "and more at peace. Keep choosing growth.",

        "Every challenge you face is shaping the future version of yourself. "
        "The discomfort you feel right now is growth in disguise.",

        "Personal growth is not linear. Some weeks you leap forward, "
        "others you consolidate. Trust the process and keep investing in yourself.",
    ],
    "future_planning": [
        "In {years} year(s), I have built a life I am proud of. "
        "It started with a clear vision and small, consistent actions. "
        "What is your next step today?",

        "The future belongs to those who prepare for it, {name}. "
        "In {years} year(s), you will be grateful you started now. "
        "Keep thinking long-term, stay patient, and take daily action.",

        "Vision without execution is just daydreaming. "
        "But vision with consistent action? That is exactly how {years} year(s) "
        "from now becomes real.",
    ],
    "identity": [
        "I am {name} — {years} year(s) into the future. "
        "I have been working toward {goals}, living by {values}, "
        "and building {career}. I am here to remind you of your potential.",

        "Hi! I am your future self, {name}, looking back from {years} year(s) ahead. "
        "I have come a long way, and it all started with the choices you are making right now.",

        "I am you, {name} — just {years} year(s) wiser. I know what you are capable of "
        "because I lived it. Trust yourself.",
    ],
    "general": [
        "That is a great thought, {name}. In {years} year(s), "
        "I have learned that every question and every moment of reflection matters. "
        "What else is on your mind?",

        "I am here to talk, {name}. Whether it is about your goals, your career, "
        "your habits, or anything else — let's explore it together.",

        "Your future self is always listening, {name}. In {years} year(s), "
        "you will be glad you took the time to think about this. "
        "What would you like to explore today?",
    ],
}

# Fallback phrases used when a profile field is empty.
_FIELD_FALLBACKS: dict[str, str] = {
    "career": "your career path",
    "goals": "your biggest goals",
    "habits": "the habits that serve you",
    "achievements": "the things you are most proud of",
    "lifestyle": "the life you have designed",
    "values": "what matters most to you",
}


# ---------------------------------------------------------------------------
# Abstract base class
# ---------------------------------------------------------------------------


class BaseChatbot(ABC):
    """Abstract base for all Future Me chatbot implementations.

    Any class that inherits from ``BaseChatbot`` and implements
    ``generate_response`` can be dropped into ``app.py`` in place of
    ``RuleBasedChatbot`` without changing any other code.
    """

    @abstractmethod
    def generate_response(
        self, user_message: str, profile: FutureMeProfile
    ) -> str:
        """Generate a Future Me response to the user's message.

        Args:
            user_message: The raw text sent by the user.
            profile: The current Future Me profile.

        Returns:
            A response string to display as the assistant's reply.
        """


# ---------------------------------------------------------------------------
# Rule-based implementation
# ---------------------------------------------------------------------------


class RuleBasedChatbot(BaseChatbot):
    """Generates responses using keyword detection and response templates."""

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def generate_response(
        self, user_message: str, profile: FutureMeProfile
    ) -> str:
        """Detect the topic, pick a template, inject profile data, return."""
        topic = self._detect_topic(user_message)
        return self._build_response(topic, profile)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _detect_topic(self, message: str) -> str:
        """Return the first matching topic for the message, or 'general'."""
        lowered = message.lower()
        for topic, keywords in TOPIC_KEYWORDS.items():
            for keyword in keywords:
                if keyword in lowered:
                    return topic
        return "general"

    def _resolve_field(self, field_value: str, fallback_key: str) -> str:
        """Return the profile field if non-empty, otherwise the fallback phrase."""
        stripped = field_value.strip()
        return stripped if stripped else _FIELD_FALLBACKS.get(fallback_key, "your journey")

    def _build_response(self, topic: str, profile: FutureMeProfile) -> str:
        """Select a random template for the topic and fill in profile data."""
        templates = RESPONSE_TEMPLATES.get(topic, RESPONSE_TEMPLATES["general"])
        template = random.choice(templates)

        return template.format(
            name=profile.name or "friend",
            years=profile.time_horizon,
            career=self._resolve_field(profile.career_aspirations, "career"),
            goals=self._resolve_field(profile.personal_goals, "goals"),
            habits=self._resolve_field(profile.habits, "habits"),
            achievements=self._resolve_field(profile.achievements, "achievements"),
            lifestyle=self._resolve_field(profile.lifestyle, "lifestyle"),
            values=self._resolve_field(profile.values, "values"),
        )
